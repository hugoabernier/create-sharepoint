     _-----_     ╭──────────────────────────╮
    |       |    │ Welcome to the Microsoft │
    |--(o)--|    │      365 SPFx Yeoman     │
   `---------´   │     Generator@1.21.1     │
    ( _´U`_ )    ╰──────────────────────────╯
    /___A___\   /
     |  ~  |
   __'.___.'__
 ´   `  |° ´ Y `

See https://aka.ms/spfx-yeoman-info for more information on how to use this generator.       
Let's create a new Microsoft 365 solution.
? What is your solution name? (sp-fx-throwaway) 

? Which type of client-side component to create? (Use arrow keys)
❯ WebPart
  Extension
  Library
  Adaptive Card Extension

Add new Web part to solution sp-fx-throwaway.
? What is your Web part name? (HelloWorld)

Which template would you like to use? (Use arrow keys)
❯ Minimal
  No framework
  React

      _=+#####!
   ###########|       .----------------------------------------.
   ###/    (##|(@)    |            Congratulations!            |

### ######|   \   |  Solution sp-fx-throwaway is created.  |

   ###/   /###|   (@) |     Run gulp serve to play with it!    |
   #######  ##|   /   '----------------------------------------'

### /##|(@)

   ###########|
      **=+####!
