module.exports = {
  root: true,
  extends: ['@microsoft/eslint-config-spfx'],
  rules: {
    // Your preferences here
  }
};
