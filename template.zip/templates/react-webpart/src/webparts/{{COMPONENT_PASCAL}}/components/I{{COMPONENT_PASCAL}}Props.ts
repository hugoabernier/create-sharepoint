import { WebPartContext } from '@microsoft/sp-webpart-base';

export interface I{{COMPONENT_PASCAL}}Props {
  context: WebPartContext;
  description?: string;
}
